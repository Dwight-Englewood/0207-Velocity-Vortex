#/bin/bash
cd ~/programming/0207Programming
#That directory might have to be changed, depending on your system
#For WEN