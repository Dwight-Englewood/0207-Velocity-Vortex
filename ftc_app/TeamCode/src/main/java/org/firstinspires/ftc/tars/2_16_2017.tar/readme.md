#### TODO
* Finish gridFunctions(void)
    * Funtions to make
        * Make a vector move
        * Make a move from coord to coord
    * This will require the circumference of the wheels
        * Possibly could be done with a variable for the circumference, but that might get messy
* Make own object for a set of instructions
    * This will make the functions better, since all the gridFunctions methods will return the object instead of void
    * Not sure what it should actually be
        * List of powers/rotations?
* How to deal with powers/rotations
    * Are we always at max power?

 #### CONFIG
 The config currently is:

